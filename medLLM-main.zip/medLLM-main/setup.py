from setuptools import find_packages, setup

setup(
    name = 'Generative AI Project',
    version= '0.0.0',
    author= 'Shreyash Pingle',
    author_email= 'shreypingle23@gmail.com',
    packages= find_packages(),
    install_requires = []

)